# java-maven-selenium-junit5-allure

Default QA framework blueprint. **Maturity: stable** (since Phase 102a) — the manifest
is real and `qaff create` now emits a buildable Java/Maven/Selenium 4/JUnit 5/
Allure 2 multi-module project.

## Stack

| Concern | Choice |
|---|---|
| Language | Java 21 (default) / Java 17 (compatibility) |
| Build tool | Maven 3.9 multi-module |
| Test runner | JUnit 5 |
| Web automation | Selenium 4 (Selenium Manager — no hard-coded driver paths) |
| Reporting | Allure 2 |

## What this blueprint generates

```
<project>/
├── pom.xml
├── framework-core/
├── framework-web/
├── apps/
│   └── <app-id>/
│       └── web-desktop/
└── qa-factory.lock.json
```

Real Maven / Selenium 4 / JUnit 5 / Allure 2 sources are emitted by the
renderer in `generator/src/generate/generateProject.ts`. The `template/`
directory is currently a placeholder; future blueprints may move some
file content there.

## Files in this blueprint

- [`blueprint.yaml`](blueprint.yaml) — machine-readable manifest consumed by the generator.
- [`template/`](template/) — placeholder for blueprint-local template files (unused in MVP 1).
- [`README.md`](README.md) — this file.

## See also

- [docs/blueprint-system.md](../../docs/blueprint-system.md) — how blueprints work.
