# ts-npm-playwright

TypeScript + npm + Playwright QA framework blueprint. **Maturity: beta** (since Phase 102 —
supported for its documented layers; Java remains the flagship) — the
manifest is real and `qaff create` emits a buildable TypeScript/Playwright multi-package
npm workspace project. The blueprint is on a **parity track** with the Java flagship. It
supports the `web-desktop` / `web-mobile` layers, all five CI providers, and — since
Phase 74 — the **Quality Impact Pack** (`api` / `integration` / `performance` layers,
the shared `framework-api` and `framework-performance` modules, k6 as the reference
performance provider, and the opt-in CI quality/trend gates). Since Phase 99 the
**MCP Toolkit** (`packs.mcpToolkit: true`) is supported: the local MCP server under
`.ai/mcp/server/` plus the pinned `allure-playwright` reporter, whose raw results in
the git-ignored root `allure-results/` feed `qaff analyze-failures` and the server's
`read_test_results` (attributed to app/layer by spec path — see
[TS Allure results](../../docs/blueprint-system.md#ts-allure-results-phase-99); example:
[`multi-app-ts-mcp.yaml`](../../examples/configs/multi-app-ts-mcp.yaml)). Since Phase 100
the toolkit is complete: the full `.ai/mcp/` tree (README, tool contracts, compatibility
specs) in Playwright/npm wording, with `suggest_test_implementation` planning
`apps/<id>/<layer>/tests/<Name>.spec.ts` / `pages/<Name>Page.ts` targets. Since Phase 101
the **AI Agent Pack** (`ai.enabled` / `packs.aiAgent`) renders the `.ai/` agents,
instructions, contracts and prompts and the AI authoring docs in TypeScript/Playwright
wording, `ai.clients: [claude-code]` adds the Claude Code adapter, and with the MCP
Toolkit on `ci.jenkins.zephyrSync` / `ci.githubActions.zephyrSync` render opt-in Zephyr
Scale Cloud sync steps (example:
[`multi-app-ts-ai-mcp.yaml`](../../examples/configs/multi-app-ts-ai-mcp.yaml)). The
offline performance producer (`ci.<provider>.performanceRun`) stays Java-only and is
rejected for this blueprint. Since Phase 102 `qaff scaffold-test` also covers the
`api` / `integration` / `performance` layers (`<Name>.spec.ts`); `scaffold-page` /
`scaffold-component` stay web-only (page objects are a web concept). See
[docs/blueprint-system.md → Blueprint strategy](../../docs/blueprint-system.md#blueprint-strategy)
for the plan and promotion criteria.

## Stack

| Concern | Choice |
|---|---|
| Language | TypeScript (Node.js 20 default / Node.js 18 and 22 options) |
| Build tool | npm workspaces |
| Test runner | Playwright |
| Web automation | Playwright (built-in) |
| Reporting | Playwright HTML reporter |

## What this blueprint generates

```
<project>/
├── package.json
├── playwright.config.ts
├── tsconfig.json
├── .github/workflows/playwright.yml   # only when ci.githubActions.enabled: true
├── framework-core/
├── framework-web/
├── framework-api/                     # Quality Impact Pack only (api layer)
├── framework-performance/             # Quality Impact Pack only (thresholds/baseline/reports)
├── scripts/run-k6-import-smoke.sh     # Quality Impact Pack only
├── apps/
│   └── <app-id>/
│       ├── web-desktop/
│       │   ├── tests/smoke.spec.ts
│       │   ├── pages/<App>HomePage.ts
│       │   └── fixtures/<app-id>.html
│       ├── api/                       # Quality Impact Pack only
│       ├── integration/               # Quality Impact Pack only
│       └── performance/               # Quality Impact Pack only (k6 template)
└── qa-factory.lock.json
```

With `packs.qualityImpact: true` the renderer additionally emits the
`api` / `integration` / `performance` layers plus the shared `framework-api`
(Playwright `APIRequestContext`) and `framework-performance` modules. Results
are produced with k6 and imported via
`qaff import-performance-result --provider k6`; `npm test` only validates the
performance scaffolding and never runs k6.

Real TypeScript/Playwright sources are emitted by the renderer in
`generator/src/generate/generatePlaywrightProject.ts`. The `template/` directory
is a placeholder; future blueprints may move some file content there.

## Run the generated framework

```bash
cd <project>
npm install
npx playwright install   # one-time browser download
npm test                 # tsc --build (framework-* packages) then playwright test
```

`npm test` runs a Playwright smoke against each app's bundled local HTML fixture in
headless Chromium — no network or external site required.

## Files in this blueprint

- [`blueprint.yaml`](blueprint.yaml) — machine-readable manifest consumed by the generator.
- [`template/`](template/) — placeholder for blueprint-local template files (unused in MVP 1).
- [`README.md`](README.md) — this file.

## See also

- [docs/blueprint-system.md](../../docs/blueprint-system.md) — how blueprints work.
